django ERP - Default Theme
==========================

This is the default theme for **django ERP** which offers a clean and modern _Look & Feel_.

Icons
-----

This theme is using some icons from:

 * The **Silk icon set** project by Mark James: http://www.famfamfam.com/lab/icons/silk/
 * The **Noun Project**: http://www.thenounproject.com

Author's details
----------------

 * **Copyright:** (c) 2013 Emanuele Bertoldi
 * **Email:** <emanuele.bertoldi@gmail.com>
